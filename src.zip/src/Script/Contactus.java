package Script;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Generic.BaseTest;
import Generic.Ecxeldata;
import Pom.CraftsvillaContactUsPage;

@Listeners(Generic.itest.class)
public class Contactus extends BaseTest {
@Test
public void ContactusTest()
{
	String s=Ecxeldata.retrievedata(PATH,"crsftsvillaModule",0,1);
	String t=Ecxeldata.retrievedata(PATH,"crsftsvillaModule",0,2);
	CraftsvillaContactUsPage p=new CraftsvillaContactUsPage(driver);
	p.clickcontactus();

p.verifyUrl(s);
p.clickhelp();
driver.navigate().back();
driver.navigate().forward();
driver.close();

	
}
}
	
	

	

