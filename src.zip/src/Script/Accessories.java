package Script;

import org.testng.annotations.Test;

import Generic.BaseTest;
import Pom.AccesoriesproductPage;
import Pom.CraftsvillaHomePage;

public class Accessories extends BaseTest{
	@Test
	public void accessoriestest() throws InterruptedException
	{
		CraftsvillaHomePage h=new CraftsvillaHomePage(driver);
		h.clickAccessories();
		AccesoriesproductPage a=new AccesoriesproductPage(driver);
		a.Clickimage();
		CraftsvillaHomePage c=new CraftsvillaHomePage(driver);
		c.clickSarees();
		driver.manage().window().maximize();
		driver.navigate().back();
	}

}
