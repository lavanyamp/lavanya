package Script;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Generic.BaseTest;
import Generic.Ecxeldata;
import Pom.CraftsvillaHomePage;
import Pom.CraftsvillaProductPage;



@Listeners(Generic.itest.class)
public class CrsftsvillaModule extends BaseTest {
	@Test
	public void testCrsftsvillaModule() throws InterruptedException
	{
	String s=Ecxeldata.retrievedata(PATH,"crsftsvillaModule",0,0);
		CraftsvillaHomePage c=new CraftsvillaHomePage(driver);
		c.clickCraftsVilla();
		CraftsvillaProductPage v=new CraftsvillaProductPage(driver);
		
		v.verifycraftsvillaProductUrl(s);
		
		v.discountClick();
		Thread.sleep(5000);
		c.clickSarees();
		driver.navigate().back();
		v.verifycraftsvillaProductUrl(s);
		
	}

}
