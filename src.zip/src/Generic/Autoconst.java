package Generic;

public interface Autoconst {

	String gecko_key="webdriver.gecko.driver";
	String gecko_value="./drivers/geckodriver.exe";
	String chrome_key="webdriver.chrome.driver";
	String chrome_value="./drivers/chromedriver.exe";
	String PATH="./excel/excelframework.xls";
}
